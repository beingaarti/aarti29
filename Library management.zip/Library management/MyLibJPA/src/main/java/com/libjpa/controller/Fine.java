package com.libjpa.controller;





import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.libjpa.dto.BooksTransaction;
import com.libjpa.service.UsersJPAService;

@Controller
public class Fine {
	@Autowired
	UsersJPAService service;
	@RequestMapping(value="/fine", method=RequestMethod.GET)
	public ModelAndView getApplicationUpdate(ModelAndView mv)
	{
		mv.setViewName("return");
		return mv;

	}        
	

	@RequestMapping(value="/fine", method=RequestMethod.POST)
	public String doApplicationUpdate(HttpServletResponse resp,
			@RequestParam("id") String transid ,
			@RequestParam("return") Date returndate,

			BooksTransaction  b, ModelAndView mv) throws ServletException, IOException, ClassNotFoundException, SQLException {
		{

			b.setTransactionid(transid);
			b.setReturndate(returndate);


			boolean state=service.fine(returndate,transid);
			
			if(state)
			{
				return "Fine111";
				
			}else
			{
				return "Fine222";
			
			}
//			
		}



	}
}



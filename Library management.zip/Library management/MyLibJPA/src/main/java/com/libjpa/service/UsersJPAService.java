package com.libjpa.service;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.libjpa.dao.UsersDAO;
import com.libjpa.dao.UsersJPAImpl;
import com.libjpa.dto.BooksInventory;
import com.libjpa.dto.BooksRegistration;
import com.libjpa.dto.BooksTransaction;
import com.libjpa.dto.Users;
@Service

public class UsersJPAService implements UsersDAO{
	 @Autowired
	 private UsersJPAImpl da;
	Users u1=null;
	@Override
		public Users login(String Username,String password,String role) {
			
			u1= da.login(Username,password,role);
			return u1;
		
	}

	@Override
	public boolean createUser(Users us) {
		UsersDAO udao=new  UsersJPAImpl();
		return udao.createUser(us);
	}

	@Override
	public boolean bookRegistration(BooksRegistration br) {
		UsersDAO usd=new UsersJPAImpl();
		return usd.bookRegistration(br);
	}

	@Override
	public boolean addBook(BooksInventory b) {
		UsersDAO ud=new UsersJPAImpl();
		return ud.addBook(b);
	}

	@Override
	public boolean modifyBook(BooksInventory b) {
		 UsersDAO us=new UsersJPAImpl();
		  return us.modifyBook(b);
	}

	@Override
	public boolean deleteBook(String bookid) {
		UsersDAO us=new UsersJPAImpl();
		return  us.deleteBook(bookid);
		
	}

	@Override
	public List<BooksInventory> listBooks(BooksInventory books) {
		UsersDAO dao=new UsersJPAImpl();
		List<BooksInventory> list=dao.listBooks(books);
		
		return list;
	}

	@Override
	public boolean bookTransaction(BooksTransaction bt) {
		UsersDAO ud=new UsersJPAImpl();
		return  ud.bookTransaction(bt);
	}
	@Override
	public boolean fine( Date returndate, String transactionid) throws SQLException, ClassNotFoundException {
		UsersDAO ud=new UsersJPAImpl();
		return ud.fine(   returndate, transactionid);	}
}

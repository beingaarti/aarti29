package com.libjpa.controller;

import java.io.IOException;


import javax.servlet.ServletException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.libjpa.dto.BooksInventory;
import com.libjpa.service.UsersJPAService;

@Controller
public class AddBookController {
	@Autowired
	UsersJPAService service;
	
	@RequestMapping(value="/addbookmvc", method=RequestMethod.GET)
	public ModelAndView getProgramOfferedAdd(ModelAndView mv)
	{
		mv.setViewName("addbook");
		
		return mv;
		
	}
	
	@RequestMapping(value="/addbook", method=RequestMethod.POST)
	public String doProgramOfferedAdd(HttpServletResponse resp,BooksInventory b,
			@RequestParam("bookid") String bookid,
			@RequestParam("bookname") String bookname,
			@RequestParam("author1") String author1 ,
			@RequestParam("author2") String author2,
			@RequestParam("publisher") String publisher,
			@RequestParam("yearofpublication") String yearofpublication) 
			throws ServletException,IOException {
		
		
		b.setBookid(bookid);
		b.setBookname(bookname);
		b.setAuthor1(author1);
		b.setAuthor2(author2);
		b.setPublisher(publisher);
		b.setYearofpublication(yearofpublication);
		boolean state=service.addBook(b);
		if(state)
		{
			return "Addbook1";
			
		}else
		{
			return "Addbook2";
		
		}
	

}}

	



package com.libjpa.controller;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.libjpa.dto.Users;
import com.libjpa.service.UsersJPAService;
@Controller
public class CreateUserMVC {
	@Autowired
	UsersJPAService service;
	@RequestMapping(value="/createmvc", method=RequestMethod.GET)
	public ModelAndView getApplicationUpdate(ModelAndView mv)
	{
		mv.setViewName("createuser");
		return mv;

}        
	@RequestMapping(value="/createuser", method=RequestMethod.POST)
	public String doApplicationUpdate(HttpServletResponse resp,
			@RequestParam("id") String userid,
			@RequestParam("password") String name,
			@RequestParam("pas") String pass,
			@RequestParam("password1") String email,
			@RequestParam("role") String role,
			
			Users  u, ModelAndView mv) throws ServletException, IOException {
		{
		  
		 
		u.setUserid(userid);
		u.setUsername(name);
		u.setPassword(pass);
		u.setEmailid(email);
		u.setRole(role);
		  boolean state=service.createUser(u);
			
	    	if(state==true)
			{
				
	    		return "Createuser111";
			}else
			{
				return "Createuser222";
			}
	}
	 
	
	
}
}

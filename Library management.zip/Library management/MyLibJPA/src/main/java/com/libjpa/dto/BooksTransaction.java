package com.libjpa.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BooksTransaction")
public class BooksTransaction {
	@Id
	@Column(name="transactionid")

	private   String transactionid;
	@Column(name="registrationid")
	private   String registrationid;
	@Column(name="issuedate")
	private  Date issuedate;
	@Column(name="returndate")
	private   Date returndate;
	@Column(name="fine")
	private  double fine;
	public String getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(String transactionid) {
		this.transactionid = transactionid;
	}
	public String getRegistrationid() {
		return registrationid;
	}
	public void setRegistrationid(String registrationid) {
		this.registrationid = registrationid;
	}
	public Date getIssuedate() {
		return issuedate;
	}
	public void setIssuedate(Date issuedate) {
		this.issuedate = issuedate;
	}
	public Date getReturndate() {
		return returndate;
	}
	public void setReturndate(Date returndate) {
		this.returndate = returndate;
	}
	public double getFine() {
		return fine;
	}
	public void setFine(double fine) {
		this.fine = fine;
	}
	@Override
	public String toString() {
		return "BooksTransaction [transactionid=" + transactionid + ", registrationid=" + registrationid
				+ ", issuedate=" + issuedate + ", returndate=" + returndate + ", fine=" + fine + "]";
	}
	
}


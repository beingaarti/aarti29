package com.libjpa.controller;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.libjpa.dto.BooksRegistration;
import com.libjpa.service.UsersJPAService;
@Controller
public class BooksRegistrationMVC {
	@Autowired
	UsersJPAService service;
	@RequestMapping(value="/bookmvc", method=RequestMethod.GET)
	public ModelAndView getApplicationUpdate(ModelAndView mv)
	{
		mv.setViewName("BookRegistration1");
		return mv;

}        
	@RequestMapping(value="/BookRegistration1", method=RequestMethod.POST)
	public String doApplicationUpdate(HttpServletResponse resp,
			@RequestParam("BookId") String BookId,
			@RequestParam("registrationId") String registrationId,
			
			@RequestParam("UserId") String UserId,
			@RequestParam("RegistrationDate") String RegistrationDate,
			
			BooksRegistration  b, ModelAndView mv) throws ServletException, IOException {
		{
		  
		  
		  b.setBookid(BookId);
		b.setRegistrationid(registrationId);
	
		b.setUserid(UserId);
		b.setRegistrationdate(RegistrationDate);
		 
		  boolean state=service.bookRegistration(b);
			
	    	if(state==true)
			{
	    		return "Bookrestn111";
				
				
			}else
			{
				
				return "Bookrestn222";
			
			}
	}
	 
	
	
}
}

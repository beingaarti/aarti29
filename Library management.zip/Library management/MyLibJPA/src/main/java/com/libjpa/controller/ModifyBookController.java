package com.libjpa.controller;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.libjpa.dto.BooksInventory;
import com.libjpa.service.UsersJPAService;

@Controller
public class ModifyBookController {

	@Autowired
	UsersJPAService service;
	@RequestMapping(value="/bookupdatemvc", method=RequestMethod.GET)
	public ModelAndView getApplicationUpdate(ModelAndView mv)
	{
		mv.setViewName("ModifyBook");
		return mv;

}        
	@RequestMapping(value="/ModifyBook", method=RequestMethod.POST)
	public String doApplicationUpdate(HttpServletResponse resp,
			@RequestParam("bookid") String bookid,
			@RequestParam("bookname") String bookname,
			@RequestParam("author1") String author1,
			@RequestParam("author2") String author2,
			@RequestParam("publisher") String publisher,
			@RequestParam("yearofpublication") String yearofpublication ,
			BooksInventory  b, ModelAndView mv) throws ServletException, IOException {
		{
		  
		 
		 b.setBookid(bookid);
		 b.setBookname(bookname);
		 b.setAuthor1(author1);
		 b.setAuthor2(author2);
		 b.setPublisher(publisher);
		 b.setYearofpublication(yearofpublication);
		 
		  boolean state=service.modifyBook(b);
			
	    	if(state==true)
			{
	    		return "Modify111";
				
			}else
			{
				return "Modify222";
				
			}
	}
	 
	
	
}
}

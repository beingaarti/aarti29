package com.libjpa.controller;

import java.io.IOException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.libjpa.dto.BooksTransaction;
import com.libjpa.service.UsersJPAService;
@Controller
public class BookstransactionMVC {
	@Autowired
	UsersJPAService service;
	@RequestMapping(value="/booktransactionmvc", method=RequestMethod.GET)
	public ModelAndView getApplicationUpdate(ModelAndView mv)
	{
		mv.setViewName("booktransaction");
		return mv;
	}

        

	@RequestMapping(value="/booktransaction", method=RequestMethod.POST)
	public String doApplicationUpdate(HttpServletResponse resp,
			@RequestParam("userid") String transactionid,
			@RequestParam("password") String registrationid,
			@RequestParam("password1") String issuedate,
			@RequestParam("pass") String returndate,
			
			BooksTransaction  b, ModelAndView mv) throws ServletException, IOException {
		{

			Date utilDate = null;
			try {
				utilDate = (Date) new SimpleDateFormat("yyyy-MM-dd").parse( issuedate);
				
			} catch (ParseException e1) {
			
				e1.printStackTrace();
			}
			
		
			Date utilDate1 = null;
			try {
				utilDate1 = (Date) new SimpleDateFormat("yyyy-MM-dd").parse(returndate);
				
			} catch (ParseException e) {
				
				e.printStackTrace();
			}
			java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime()); 
			java.sql.Date sqlDate1 = new java.sql.Date(utilDate1.getTime());
			
		
			
		  
		b.setTransactionid(transactionid);
		b.setRegistrationid(registrationid);
		b.setIssuedate(sqlDate);
		b.setReturndate(sqlDate1);
		  boolean state=service.bookTransaction(b);
			
	    	if(state==true)
			{
				
	    		return "Booktrans111";
				
				
				
			}else
			{
				
				return "Booktrans222";
				
			}
}
}
}
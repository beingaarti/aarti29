package com.libjpa.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="booksregistration")

public class BooksRegistration {
	@Column(name="bookid")
	private   String bookid;
	@Id
	@Column(name="registrationid")
	private   String registrationid;
	
	@Column(name=" userid")
	private   String userid;
	@Column(name="registrationdate")
	private   String registrationdate;
	public String getBookid() {
		return bookid;
	}
	public void setBookid(String bookid) {
		this.bookid = bookid;
	}
	public String getRegistrationid() {
		return registrationid;
	}
	public void setRegistrationid(String registrationid) {
		this.registrationid = registrationid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getRegistrationdate() {
		return registrationdate;
	}
	public void setRegistrationdate(String registrationdate) {
		this.registrationdate = registrationdate;
	}
	@Override
	public String toString() {
		return "BooksRegistration [bookid=" + bookid + ", registrationid=" + registrationid + ", userid=" + userid
				+ ", registrationdate=" + registrationdate + "]";
	}
	
	
	
}

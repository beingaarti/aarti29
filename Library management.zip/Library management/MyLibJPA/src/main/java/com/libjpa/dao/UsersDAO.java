package com.libjpa.dao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import com.libjpa.dto.BooksInventory;
import com.libjpa.dto.BooksRegistration;
import com.libjpa.dto.BooksTransaction;
import com.libjpa.dto.Users;

public interface UsersDAO {

	public Users login(String Username,String  password, String role);

	public boolean createUser(Users us);

	public boolean bookRegistration(BooksRegistration br);

	public boolean addBook(BooksInventory b);

	public boolean modifyBook(BooksInventory b);

	public boolean deleteBook(String bookid);

	public  List<BooksInventory> listBooks(BooksInventory books);

	public boolean bookTransaction(BooksTransaction bt);

	boolean fine( Date returndate,String transactionid) throws SQLException, ClassNotFoundException;//xcvghj



}

package com.libjpa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.libjpa.dto.BooksInventory;
import com.libjpa.service.UsersJPAService;


@Controller
public class ListOfBookMVC {
	@Autowired
	UsersJPAService service;
	
	@RequestMapping(value="/listOfBookmvc",method=RequestMethod.GET)
	public ModelAndView getPrograms(ModelAndView mv){
		mv.setViewName("bookinven");
		return mv;
	}
	
	@RequestMapping(value="/ListAllBooks", method=RequestMethod.POST)
	public void listAllProgramsOffered(HttpServletResponse resp,ModelAndView mv) throws IOException
	{
		PrintWriter printWriter=resp.getWriter();
		BooksInventory books=new BooksInventory();
		   List<BooksInventory> list=service.listBooks(books);
			if(list!=null)
			{

				for(int i=0;i<list.size();i++)
				{
					books=list.get(i);


					printWriter.print("<table border=1 cellpadding='5' width='60%'");
					printWriter.print("<tr>");
				printWriter.print("<h3>"+"<th>"+"BOOK ID"+"<th>"+"<td>"+books.getBookid()+"</td>");
					printWriter.print("<h3>"+"<th>"+"BOOK NAME"+"<th>"+"<td>"+books.getBookname()+"</td>");
					printWriter.print("<h3>"+"<th>"+"AUTHOR1"+"<th>"+"<td>"+books.getAuthor1()+"</td>");
					printWriter.print("<h3>"+"<th>"+"AUTHOR2"+"<th>"+"<td>"+books.getAuthor2()+"</td>");
					printWriter.print("<h3>"+"<th>"+"PUBLISHER"+"<th>"+"<td>"+books.getPublisher()+"</td>");
					printWriter.print("<h3>"+"<th>"+"Yearofpublication"+"<th>"+"<td>"+books.getYearofpublication()+"</td>");
					printWriter.print("</tr>");
					printWriter.print("</table>");
				}
			}
			else
			{
				printWriter.print("<h1>"+"something went wrong"+"</h1>");
			}
}}

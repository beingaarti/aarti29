package com.libjpa.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LogoutControllerMVC {
	
	
	@RequestMapping(value="/logoutmvc",method=RequestMethod.GET)
	public ModelAndView doLogout(HttpServletResponse resp, HttpServletRequest req) throws ServletException, IOException
	{
		
		HttpSession session = req.getSession(false);
		/*PrintWriter out=resp.getWriter();*/
		
		/*if(session==null) {
			
			resp.sendRedirect("./loginmvc");
		}*/
		if(session != null) {
			session.invalidate();
			/*System.out.print("YOU HAVE LOGGED OUT");*/
			
		}
		Cookie[] cookies = req.getCookies();
		for(int i=0; i<=cookies.length ; ++i){
			if(cookies[i].getName().equals("JSESSIONID"))
			{
				cookies[i].setMaxAge(0);
				resp.addCookie(cookies[i]);
				break;
			}
			
		/*if(cookies != null) {
			for(Cookie c: cookies) {
				if(c.getName().equalsIgnoreCase("JSESSIONID")){
					c.setMaxAge(0);
					resp.addCookie(c);
				}
			}*/
		
	}return new ModelAndView("loginmvc");

}
	}

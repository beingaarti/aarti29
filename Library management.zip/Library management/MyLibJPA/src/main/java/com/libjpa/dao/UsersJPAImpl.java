package com.libjpa.dao;

import java.io.PrintWriter;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.libjpa.dto.BooksInventory;
import com.libjpa.dto.BooksRegistration;
import com.libjpa.dto.BooksTransaction;
import com.libjpa.dto.Users;
@Repository
public class UsersJPAImpl implements UsersDAO{
	@PersistenceUnit  
	EntityManagerFactory emf; /* =Persistence.createEntityManagerFactory("myPersistenceUnit"); */

	@Override
	public boolean deleteBook(String bookid) {
		boolean state=false;
		EntityManager em = emf.createEntityManager();

		try{
			em.getTransaction().begin();

			String query="delete from BooksInventory  where bookid=:bookid";
			Query qu=em.createQuery(query);
			qu.setParameter("bookid", bookid);
			int count=qu.executeUpdate();

			if(count>0)
			{
				state=true;

			}


		
		}
		catch(Exception e)
		{
			e.printStackTrace();

		}finally{
			if(em!=null){
				em.getTransaction().commit();
				em.close();
			}
		}
		return state;
	}




	@Override
	public Users login(String Username, String password,String role) {



		Users userr=null;
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin();
			String jqpl="select u from Users u where u.username=:username and u.password=:password and u.role=:role";
			Query query = em.createQuery(jqpl); 
			query.setParameter("username", Username);
			query.setParameter("password", password);
			query.setParameter("role", role);


			userr=(Users) query.getSingleResult();

			em.getTransaction().commit();
			return userr;

		}catch(Exception e) {
			e.printStackTrace();

		}finally {
			if(em!= null) {
				em.close();
			}
		}

		return userr;
	}

	@Override
	public boolean createUser(Users us) {

		boolean state=false;
		EntityManager em=null;
		em = emf.createEntityManager();
		try {
			em.getTransaction().begin();


			em.persist(us);;

			state=true;
			

		} catch(Exception e) {
			e.printStackTrace();

		}finally {
			if(em!= null) {
				em.getTransaction().commit();
				em.close();
			}
		}	
		return state;
	}

	@Override
	public boolean bookRegistration(BooksRegistration br) {
		boolean state = false;
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin();

			em.persist(br);

			state = true;

		} catch(Exception e) {
			e.printStackTrace();

		}finally {
			if(em!= null) {
				em.getTransaction().commit();
				em.close();
			}
		}


		return state;
	}


	@Override
	public boolean addBook(BooksInventory b) {

		boolean state = false;
		EntityManager em = null;
		try {
			em = emf.createEntityManager();
			em.getTransaction().begin();


			em.persist(b);

			state = true;
		}catch(Exception e) {
			e.printStackTrace();
			state = false;
		}finally {
			if(em != null) {
				em.getTransaction().commit();
				em.close();
			}
		}
		return state;
	}

	@Override
	public boolean modifyBook(BooksInventory b) {
		boolean state=false;
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin();
			String jqpl="update BooksInventory s set s.bookname=:bookname, s.author1=:author1, s.author2=:author2, s.publisher=:publisher, s.yearofpublication=:yearofpublication where s.bookid=:bookid";
			Query query = em.createQuery(jqpl); 
			query.setParameter("bookname",b.getBookname());
			query.setParameter("author1",b.getAuthor1());
			query.setParameter("author2",b.getAuthor2());
			query.setParameter("publisher",b.getPublisher());
			query.setParameter("yearofpublication",b.getYearofpublication());
			query.setParameter("bookid",b.getBookid());
			int count=query.executeUpdate();

			em.getTransaction().commit();
			if(count>0) {
				state = true;
			}
		}catch(Exception e) {
			e.printStackTrace();

		}finally {
			if(em!= null) {
				em.close();
			}}

		return state;

	}


		@Override
	public List<BooksInventory> listBooks(BooksInventory books) {
		EntityManager em = emf.createEntityManager();
		List<BooksInventory> list = new ArrayList<BooksInventory>();
		try {
			em.getTransaction().begin();
			String jqpl= "select b from BooksInventory b ";
			TypedQuery<BooksInventory> query = em.createQuery(jqpl,BooksInventory.class); 

			list=query.getResultList();



		}catch(Exception e) {
			e.printStackTrace();

		}finally {
			if(em!= null) {
				em.getTransaction().commit();
				em.close();
			}}
		return list;

	}

	@Override
	public boolean bookTransaction(BooksTransaction bt) {
		boolean state = false;
		EntityManager em = null;
		try {
			em = emf.createEntityManager();
			em.getTransaction().begin();




			em.persist(bt);

					state = true;
		}catch(Exception e) {
			e.printStackTrace();
			state = false;
		}finally {
			if(em != null) {
				em.getTransaction().commit();
				em.close();
			}
		}
		return state;
	}

	public boolean fine( Date returndate, String transactionid) throws SQLException, ClassNotFoundException {
		EntityManager em = emf.createEntityManager();
		boolean state = false;
		try{
			em.getTransaction().begin();
			BooksTransaction booksT = em.find(BooksTransaction.class, transactionid);
			java.util.Date issueDate = booksT.getIssuedate();

			//compare issue date to return date
							SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			
							Date d1 = null;
							Date d2 = null;
							d2 = returndate;
							java.sql.Date sqlDate1 = new java.sql.Date(d2.getTime()); 
			
							//in milliseconds
							long diff = returndate.getTime() -  issueDate.getTime();
			
							long diffDays = diff / (24 * 60 * 60 * 1000);
							float fine = 0;
							if(diffDays>14)
							{
								fine =(int) (diffDays-14);
							}
			
			booksT.setFine(fine);
			em.getTransaction().commit();
			state = true;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return state;
	}

}





package com.libjpa.repo;

public class URL {
	
	
	public static String getURL()
	{
		String url = "jdbc:mysql://localhost:3306/uas?user=root&password=ayush@12";
		return url;
	}
	public  static String getDriver()
	{
		String url = "com.mysql.cj.jdbc.Driver";
		return url;
	}

	
	public  static String getProperty()
	{
		String url = "C:/Users/ayush/Desktop/prop.properties";
		return url;
	}

}

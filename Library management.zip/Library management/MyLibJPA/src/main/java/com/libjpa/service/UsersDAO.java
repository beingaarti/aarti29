package com.libjpa.service;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import com.libjpa.dto.BooksInventory;



public interface UsersDAO {

	public UsersDAO login(String Username,String  password,String role);

	public boolean createUser(UsersDAO us);

	public boolean bookRegistration(com.libjpa.dto.BooksRegistration br);

	public boolean addBook(com.libjpa.dto.BooksInventory b);

	public boolean modifyBook(com.libjpa.dto.BooksInventory b);

	public boolean deleteBook(String bookname);

	public  List<BooksInventory> listBooks(BooksInventory books);


	public boolean bookTransaction(com.libjpa.dto.BooksTransaction bt);


	int fine( Date returndate,String transactionsid) throws SQLException, ClassNotFoundException;



}

package com.libjpa.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
public class JPAConfig {
	
	
	@Bean  ()         
	public LocalEntityManagerFactoryBean entityManagerFactoryBean() {        
		LocalEntityManagerFactoryBean emfb = new LocalEntityManagerFactoryBean();
		emfb.setPersistenceUnitName("myPersistenceUnit");  
		return emfb;
	}
	}

package com.libmanagement.dao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import com.libmanagement.dto.BooksInventory;
import com.libmanagement.dto.BooksRegistration;
import com.libmanagement.dto.BooksTransaction;
import com.libmanagement.dto.Users;

public interface UsersDAO {

	public Users login(String Username,String  password,String role);

	public boolean createUser(Users us);

	public boolean bookRegistration(BooksRegistration br);

	public boolean addBook(BooksInventory b);

	public boolean modifyBook(BooksInventory b);

	public boolean deleteBook(String bookId);

	public  List<BooksInventory> listBooks(BooksInventory books);


	public boolean bookTransaction(BooksTransaction bt);
	//public double fine(String Transactionid);

	boolean fine(int fine, Date returndate,String transactionid) throws SQLException, ClassNotFoundException;



}

package com.libmanagement.dto;

import java.sql.Date;

public class BooksTransaction {
	private   String transactionid;
	private   String registrationid;
	private  String issuedate;
	private   String returndate;
	private  double fine;
	public String getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(String transactionid) {
		this.transactionid = transactionid;
	}
	public String getRegistrationid() {
		return registrationid;
	}
	public void setRegistrationid(String registrationid) {
		this.registrationid = registrationid;
	}
	public String getIssuedate() {
		return issuedate;
	}
	public void setIssuedate(String issuedate) {
		this.issuedate = issuedate;
	}
	public String getReturndate() {
		return returndate;
	}
	public void setReturndate(String returndate) {
		this.returndate = returndate;
	}
	public double getFine() {
		return fine;
	}
	public void setFine(double fine) {
		this.fine = fine;
	}
	@Override
	public String toString() {
		return "BooksTransaction [transactionid=" + transactionid + ", registrationid=" + registrationid
				+ ", issuedate=" + issuedate + ", returndate=" + returndate + ", fine=" + fine + "]";
	}
	
	
	
}

package com.libmanagement.repo;

public class URL {

	public static  String getURL()
	{
		String url = "jdbc:mysql://localhost:3306/lib_management?user=root&password=ayush@12";
		return url;
	}
}

package com.libmanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.libmanagement.dto.BooksInventory;
import com.libmanagement.service.LoginService;
@WebServlet("/modify")

public class ModifyServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		String bId=req.getParameter("bookid");
		String bookName=req.getParameter("bookname");
		String author1=req.getParameter("author1");
		String author2=req.getParameter("author2");
		String publisher=req.getParameter("publisher");
		String yop=req.getParameter("yearofpublication");
		

		BooksInventory b=new BooksInventory();
		b.setBookid(bId);
		b.setBookname(bookName);
		b.setAuthor1(author1);
		b.setAuthor2(author2);
		b.setPublisher(publisher);
		b.setYearofpublication(yop);
		

		LoginService mbs=new LoginService();
		boolean b4=mbs.modifyBook(b);

		if(b4) {
			out.print("<h1>"+"Successfully book Modified");
		} else {
			out.print("<h1>"+"Modification Failed"+"</h1>");
		}





	}

}

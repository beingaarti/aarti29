package com.libmanagement.service;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;


import com.libmanagement.dao.UsersDAO;
import com.libmanagement.dao.UsersJDBCImpl;
import com.libmanagement.dto.BooksInventory;
import com.libmanagement.dto.BooksRegistration;
import com.libmanagement.dto.BooksTransaction;

import com.libmanagement.dto.Users;

public class LoginService implements UsersDAO{

	Users u1=null;
		public Users login(String Username,String password,String role) {
			UsersJDBCImpl da = new UsersJDBCImpl();
			u1= da.login(Username,password,role);
			return u1;
		
		}
		@Override
		public boolean createUser(Users us) {

			UsersDAO udao=new UsersJDBCImpl();
			return udao.createUser(us);
		
		}
		public boolean bookRegistration(BooksRegistration br) {
			UsersDAO usd=new UsersJDBCImpl();
			return usd.bookRegistration(br);
		}

		
		

		@Override
		public boolean addBook(BooksInventory b) {
			UsersDAO ud=new UsersJDBCImpl();
			return ud.addBook(b);
		}

		@Override
		public boolean modifyBook(BooksInventory b) {
			  UsersDAO us=new UsersJDBCImpl();
			  return us.modifyBook(b);
		}

		@Override
		public boolean deleteBook(String bookId) {
			UsersJDBCImpl us=new UsersJDBCImpl();
			boolean u1= us.deleteBook(bookId);
			return u1;
		}

		@Override
		public List<BooksInventory> listBooks(BooksInventory books) {
			UsersDAO dao=new UsersJDBCImpl();
			List<BooksInventory> list=dao.listBooks(books);
			
			return list;

		}

		@Override
		public boolean bookTransaction(BooksTransaction bt) {
			UsersDAO ud=new UsersJDBCImpl();
			return  ud.bookTransaction(bt);
		}
		@Override
		public boolean fine(int fine, Date returndate, String transactionid) throws SQLException, ClassNotFoundException {
			UsersDAO ud=new UsersJDBCImpl();
			return ud.fine( fine,  returndate, transactionid);
		}

			
	


	}

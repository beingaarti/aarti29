package com.libmanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.libmanagement.repo.URL;

@WebServlet("/dateret")

public class ColReturndate extends HttpServlet{
	java.sql.Connection con=null;
	 java.sql.PreparedStatement pstmt=null;
	 ResultSet rs=null;
	 
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		String return1 = req.getParameter("id");
		String return123 = req.getParameter("return");
		//BooksTransaction date1=new BooksTransaction();
		 try {
			 //step=1;
			 Class.forName("com.mysql.jdbc.Driver");
			 //step=2;
				
				con = DriverManager.getConnection(URL.getURL());
				//step=3;
				String query = "select issuedate from bookstransaction  where transactionid=?  ";
				pstmt = con.prepareStatement(query);
				

				pstmt.setString(1,return1);
			
				//pstmt.addBatch(query);
				System.out.println("executed1");
				rs=pstmt.executeQuery();
				System.out.println("executed");
				if(rs.next())
				{
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

					Date d1 = null;
					Date d2 = null;

					
						d1 = format.parse( rs.getString("issuedate"));
						d2 = format.parse( return123);
						java.sql.Date sqlDate1 = new java.sql.Date(d2.getTime()); 

						//in milliseconds
						long diff = d2.getTime() - d1.getTime();

						long diffDays = diff / (24 * 60 * 60 * 1000);
						if(diffDays>14)
						{
							int a=(int) (diffDays-14);
							out.print("<center>"+"<h1>" +"fine isss"+ ((diffDays-14))+ "</h1>"+"<center>");	
							
							String s=Integer.toString(a);
							
							String query1= "update BooksTransaction set fine=? where transactionid=?";
							pstmt = con.prepareStatement(query1);		
							pstmt.setString(1, s);
							pstmt.setString(2,return1 );
							
							int count =pstmt.executeUpdate();
							
							
							if(count>0) {
								out.print("fine updated");  			
							}else{
								out.print("fine not updated"); 
							}

							
							
							
							
							
//							pstmt.addBatch(query1);
//							int count[] = pstmt.executeBatch();
//							int successCount=count.length;
//							for(int i=0;i<successCount;i++)
//							{
//								int sucess=count[i];
//								if(sucess>0){
//									System.out.println("updated fine");
//								}
//
//							}
//
//							con.commit();
//							con.setAutoCommit(true);
//								  			
//							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
//							CheckDate ss=new  CheckDate ();
//							ss.setFine(a);
//							ss.setReturndate(sqlDate1 );
//							ss.setTransactionid(return1);
//							LoginService log=new LoginService();
//							log.fine(a, sqlDate1, return1);
////							
//						if(log!=null) {
//							out.print("<h1>"+"Successfully completed");
//						
//							
//							}else
//								
//							{
//								out.print("<h1>"+" failed"+"</h1>");
//							
//						}
						}
						else
						{
							out.print("<center>"+"<h1>" +"fine isss"+ "NO FINE "+ "</h1>"+"<center>");				
						}
						
					

			
				
		
				}
		 }
	
			 
		 catch(Exception e)
		 
		 {
			e.printStackTrace(); 
		 }
		 finally
		 {
			 if(con!=null)
				{
					try {
						con.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				if(pstmt!=null)
				{
					try {
						pstmt.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if(rs!=null)
				{
					try {
						rs.close();
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
				
				}
		 }
			
		
		}
	}	
	

package com.libmanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.libmanagement.dto.BooksTransaction;
import com.libmanagement.service.LoginService;

@WebServlet("/booktrans")
public class BookTransactionServlet extends HttpServlet
{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String tid = req.getParameter("transid");
		String rid = req.getParameter("registerid");
		String issuedate = req.getParameter("issuedate");
		String returndate = req.getParameter("returndate");
		double fn = Double.parseDouble(req.getParameter("fn"));

		
		BooksTransaction bt = new BooksTransaction();
		bt.setTransactionid(tid);
		bt.setRegistrationid(rid);
		bt.setIssuedate(issuedate);
		bt.setReturndate(returndate);
		bt.setFine(fn);
		System.out.println("hjhukh");
		LoginService bt1=new LoginService();
		boolean b=bt1.bookTransaction(bt);
		PrintWriter out = resp.getWriter();
		if(b){
			out.print("<h1>"+"Transaction Successufully"+"</h1>");
			//out.print("Send Request for another book");
			RequestDispatcher dis=req.getRequestDispatcher("./booktransaction.jsp");
			dis.include(req, resp);
		}else {
			resp.sendRedirect("./booktransaction.jsp");
		}
		
	}

}

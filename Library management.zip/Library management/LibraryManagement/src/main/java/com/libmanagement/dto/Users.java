package com.libmanagement.dto;

public class Users {
private   String userid;
private   String username;
private   String password;
private   String emailid;
private String role;
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public String getUserid() {
	return userid;
}
public void setUserid(String userid) {
	this.userid = userid;
}
public String getUsername() {
	return username;
}
public void setUsersname(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
@Override
public String toString() {
	return "Users [userid=" + userid + ", usersname=" + username + ", password=" + password + ", emailid="
			+ emailid + ", role=" + role + "]";
}






}

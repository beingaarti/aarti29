package com.libmanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.libmanagement.dto.BooksInventory;
import com.libmanagement.service.LoginService;
@WebServlet("/addbook")

public class AddBook extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();

		String bookId=req.getParameter("bookid");
		String bookName=req.getParameter("bookname");
		String author1=req.getParameter("author1");
		String author2=req.getParameter("author2");
		String publish=req.getParameter("publisher");
		String date=req.getParameter("date");


		BooksInventory b=new BooksInventory();
		b.setBookid(bookId);
		b.setBookname(bookName);
		b.setAuthor1(author1);
		b.setAuthor2(author2);
		b.setPublisher(publish);
		b.setYearofpublication(date);

		LoginService ads=new LoginService();

		boolean b2=ads.addBook(b);

		if(b2) {
			out.print("<h1>"+"Book Successfully Added"+"</h1>");
		

			RequestDispatcher dis=req.getRequestDispatcher("./addbook.jsp");
			dis.include(req, resp);
		} else {
			out.print("<h1>"+"Adding Book Failed"+"</h1>");

		}

	}

	}



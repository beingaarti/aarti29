package com.libmanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.libmanagement.dto.Users;
import com.libmanagement.service.LoginService;
@WebServlet("/CreateUser")

public class CreateUser extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();

		String uid=req.getParameter("id");
		String name=req.getParameter("password");
		String pass=req.getParameter("pas");
		String email=req.getParameter("password1");
		
		String role=req.getParameter("role");



		Users us=new Users();

		us.setUserid(uid);
		us.setUsersname(name);
		us.setPassword(pass);
		us.setEmailid(email);
		
		us.setRole(role);

		LoginService cs=new LoginService();
		boolean b=cs.createUser(us);

		if(b) { 
			System.out.println("Successfully created");
			resp.sendRedirect("./Login.jsp");
		} else {
			resp.sendRedirect("./createuser.jsp");
		}
	}

}

package com.libmanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.libmanagement.dto.BooksInventory;
import com.libmanagement.service.LoginService;
@WebServlet("/listbooks")

public class ListOfServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter printWriter=resp.getWriter();

		BooksInventory books=new BooksInventory();
		LoginService lis=new LoginService();
		List<BooksInventory> list=lis.listBooks(books);


		if(list!=null)
		{
			System.out.println("Entered");


			for(int i=0;i<list.size();i++)
			{
				books=list.get(i);


				printWriter.print("<table border=2 cellpadding='5' width='60%'");
				printWriter.print("<tr>");
				printWriter.print("<h3>"+"<th>"+"BOOK ID"+"<th>"+"<td>"+books.getBookid()+"</td>");
				printWriter.print("<h3>"+"<th>"+"BOOK NAME"+"<th>"+"<td>"+books.getBookname()+"</td>");
				printWriter.print("<h3>"+"<th>"+"AUTHOR1"+"<th>"+"<td>"+books.getAuthor1()+"</td>");
				printWriter.print("<h3>"+"<th>"+"AUTHOR2"+"<th>"+"<td>"+books.getAuthor2()+"</td>");
				printWriter.print("<h3>"+"<th>"+"PUBLISHER"+"<th>"+"<td>"+books.getPublisher()+"</td>");
				printWriter.print("<h3>"+"<th>"+"Yearofpublication"+"<th>"+"<td>"+books.getYearofpublication()+"</td>");
				printWriter.print("</tr>");
				printWriter.print("</table>");
			}
		}
		else
		{
			resp.sendRedirect("./librarianhome.jsp");
		}



	}
}

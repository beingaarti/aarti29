package com.libmanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.libmanagement.dto.Users;
import com.libmanagement.service.LoginService;

@WebServlet("/login")

public class LoginController extends HttpServlet{
	Users b=null;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();

		String name = req.getParameter("username");
		String pass = req.getParameter("password");
		String role = req.getParameter("role");



		LoginService ls=new LoginService();
		 b=ls.login(name,pass,role);

		 
		if(b!=null){
			HttpSession session=req.getSession();		  

			if(b.getRole().equals("Librarian"))
			{    
				
				req.setAttribute("user","b");
				
				RequestDispatcher dis= req.getRequestDispatcher("./librarianhome.jsp");
				dis.include(req, resp);
			}else if(b.getRole().equals("Student")){

				
				//req.setAttribute("user","b");
			
				RequestDispatcher dis= req.getRequestDispatcher("./Home1.jsp");
				dis.include(req, resp);
			}
			
		}else{
			
			resp.sendRedirect("./login2.jsp");
	
		
		}

	}
	}



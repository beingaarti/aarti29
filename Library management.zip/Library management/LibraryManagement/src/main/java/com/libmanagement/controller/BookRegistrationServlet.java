package com.libmanagement.controller;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.libmanagement.service.LoginService;
@WebServlet("/bookrest")
public class BookRegistrationServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String rid = req.getParameter("registrationId");
		String bookid = req.getParameter("BookId");
		String userid = req.getParameter("UserId");
		String regdate = req.getParameter("RegistrationDate");

		
		PrintWriter out = resp.getWriter();


		com.libmanagement.dto.BooksRegistration br=new com.libmanagement.dto.BooksRegistration();

		br.setRegistrationid(rid);
		br.setBookid(bookid);
		br.setUserid(userid);
		br.setRegistrationdate(regdate);

		LoginService cs=new LoginService();
		boolean b=cs.bookRegistration(br);
		if(b){
			out.print("<h1>"+"Registration Successufully"+"</h1>");
			out.print("Send Request for another book");
			RequestDispatcher dis=req.getRequestDispatcher("./BookRegistration.jsp");
			dis.include(req, resp);
		}else {
			resp.sendRedirect("./BookRegistration.jsp");
		}
		
	}

}
package com.libmanagement.dto;

public class BooksRegistration {
	private   String registrationid;
	private   String bookid;
	private   String userid;
	private   String registrationdate;
	public String getRegistrationid() {
		return registrationid;
	}
	public void setRegistrationid(String registrationid) {
		this.registrationid = registrationid;
	}
	public String getBookid() {
		return bookid;
	}
	public void setBookid(String bookid) {
		this.bookid = bookid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getRegistrationdate() {
		return registrationdate;
	}
	public void setRegistrationdate(String registrationdate) {
		this.registrationdate = registrationdate;
	}
	@Override
	public String toString() {
		return "BooksRegistration [registrationid=" + registrationid + ", bookid=" + bookid + ", userid=" + userid
				+ ", registrationdate=" + registrationdate + "]";
	}
	
	
}

   
package com.libmanagement.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.libmanagement.dto.BooksInventory;
import com.libmanagement.dto.BooksRegistration;
import com.libmanagement.dto.BooksTransaction;

import com.libmanagement.dto.Users;
import com.libmanagement.repo.URL;

public class UsersJDBCImpl implements  UsersDAO{

	
	
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	URL url = new URL();
	
	Users person =new Users();
	
	@Override
	public Users login(String Username, String password,String role) {
		java.sql.Connection con=null;
		 java.sql.PreparedStatement pstmt=null;
		 ResultSet rs=null;
		
		 try {
			 //step=1;
			 Class.forName("com.mysql.jdbc.Driver");
			 //step=2;
				
				con = DriverManager.getConnection(url.getURL());
				//step=3;
				String query = "select * from Users  where username=? and password=? ";
				pstmt = con.prepareStatement(query);
				

				pstmt.setString(1,Username);
				pstmt.setString(2,password);
			
				System.out.println("executed1");
				rs=pstmt.executeQuery();
				System.out.println("executed");
				if(rs.next())
				{
			
				String fname=rs.getString("userid");
				String lname=rs.getString("username");						
				String pass1=rs.getString("password");
				String email=rs.getString("emailid");
				
				String role1= rs.getString("role");
				person.setUserid(fname);
				person.setUsersname(lname);
				person.setEmailid(email);
				person.setRole(role1);

				System.out.println("Logged in");
				return person;
				}
			 
		 }catch(Exception e)
		 
		 {
			e.printStackTrace(); 
		 }
		 finally
		 {
			 if(con!=null)
				{
					try {
						con.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				if(pstmt!=null)
				{
					try {
						pstmt.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if(rs!=null)
				{
					try {
						rs.close();
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
					
				}

			 
		 }
	
		// TODO Auto-generated method stub
		return null;

	}

	@Override
	public boolean createUser(Users us) {
		boolean b=false;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url.getURL());

			String query= "insert into Users values(?,?,?,?,?)";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, us.getUserid());
			pstmt.setString(2,us.getUsername());
			pstmt.setString(3, us.getPassword());
			pstmt.setString(4,us.getEmailid());
			pstmt.setString(5, us.getRole());

			int count =pstmt.executeUpdate();

			if(count>0) {
				b= true;   			
			} else {
				b= false;
			}

		} catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return b;
	}

	@Override
	public boolean bookRegistration(BooksRegistration br) {
		boolean b2=false;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url.getURL());

			String query= "insert into BooksRegistration values(?,?,?,?)";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,br.getRegistrationid());
			pstmt.setString(2,br.getBookid());
			pstmt.setString(3,br.getUserid());
			pstmt.setString(4,br.getRegistrationdate());

			int count =pstmt.executeUpdate();

			if(count>0) {
				b2= true;   			
			} else {
				b2= false;
			}

		} catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return b2;
		
	}

	@Override
	public boolean addBook(BooksInventory b) {
		boolean b2=false;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url.getURL());

			String query= "insert into Booksinventory values(?,?,?,?,?,?)";
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, b.getBookid());
			pstmt.setString(2, b.getBookname());
			pstmt.setString(3, b.getAuthor1());
			pstmt.setString(4, b.getAuthor2());
			pstmt.setString(5, b.getPublisher());
			pstmt.setString(6, b.getYearofpublication());

			int count =pstmt.executeUpdate();

			if(count>0) {
				b2= true;   			
			} else {
				b2= false;
			}

		} catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt!=null)
			{
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return b2;

	}

	@Override
	public boolean modifyBook(BooksInventory b) {
		boolean b4=false;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url.getURL());

			String query= "update BooksInventory set bookname=?,author1=?,author2=?,publisher=?,yearofpublication=? where bookid=?";
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, b.getBookname());
			pstmt.setString(2, b.getAuthor1());
			pstmt.setString(3, b.getAuthor2());
			pstmt.setString(4, b.getPublisher());
			pstmt.setString(5, b.getYearofpublication());
			pstmt.setString(6, b.getBookid());

			int count =pstmt.executeUpdate();

			if(count>0) {
				b4= true;   			
			}else{
				b4= false;
			}

		} catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return b4;

		
	}


	@Override
	public boolean deleteBook(String bookId) {
		
		boolean b3=false;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection(url.getURL());

			String query= "delete from  BooksInventory where bookname=?";
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, bookId);

			int count =pstmt.executeUpdate();

			if(count>0) {
				b3= true;   			
			} else {
				b3= false;
			}

		} catch(Exception e) {
			e.printStackTrace();
		}
		finally
		{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return b3;


	}
	@Override
	public List<BooksInventory> listBooks(BooksInventory books) {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		List<BooksInventory> list=new ArrayList<BooksInventory>();
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url.getURL());
			String query = "select * from BooksInventory";

			preparedStatement = con.prepareStatement(query);
			resultSet =preparedStatement.executeQuery();

			books=new BooksInventory();
			while(resultSet.next())
			{

				books.setBookid(resultSet.getString(1));
				books.setBookname(resultSet.getString(2));
				books.setAuthor1(resultSet.getString(3));
				books.setAuthor2(resultSet.getString(4));
				books.setPublisher(resultSet.getString(5));
				books.setYearofpublication(resultSet.getString(6));

				list.add(books);

			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(preparedStatement!=null)
			{
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(resultSet!=null)
			{
				try {
					resultSet.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

			}
		}

		return list;

	}

	@Override
	public boolean bookTransaction(BooksTransaction bt) {
		PreparedStatement pstmt = null;
		boolean result=false;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url.getURL());

			String query= "insert into BooksTransaction values(?,?,?,?,?)";
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, bt.getTransactionid());
			pstmt.setString(2, bt.getRegistrationid());
			pstmt.setString(3, bt.getIssuedate());
			pstmt.setString(4, bt.getReturndate());
			pstmt.setDouble(5, bt.getFine());

			int count =pstmt.executeUpdate();

			if(count>0) {
				result= true;   			
			} else {
				result= false;
			}

		} catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt!=null)
			{
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;

	
	}

	@Override
	public boolean fine(int fine, Date returndate, String transactionid) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub@Override
		boolean b4=false;
			Statement stmt=null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection(url.getURL());
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String SQL = "UPDATE bookstransaction SET fine = ?, returndate=? where transactionid=? ";
			
			
			pstmt.setLong(1,fine);
			pstmt.setDate(2, returndate);
			pstmt.setString(3,transactionid);
			pstmt = con.prepareStatement(SQL);
			int count =pstmt.executeUpdate();

			if(count>0) {
				b4= true;   			
			}else{
				b4= false;
			}
			return b4;

		
	
			}
	

				
			
			

		
	}

 

package com.libmanagement.dto;

public class BooksInventory {
	
	private   String bookid;
	private   String bookname;
	private   String author1;
	private   String author2;
	private   String publisher;
	private   String yearofpublication;
	public String getBookid() {
		return bookid;
	}
	public void setBookid(String bookid) {
		this.bookid = bookid;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getAuthor1() {
		return author1;
	}
	public void setAuthor1(String author1) {
		this.author1 = author1;
	}
	public String getAuthor2() {
		return author2;
	}
	public void setAuthor2(String author2) {
		this.author2 = author2;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getYearofpublication() {
		return yearofpublication;
	}
	public void setYearofpublication(String yearofpublication) {
		this.yearofpublication = yearofpublication;
	}
	@Override
	public String toString() {
		return "BooksInventory [bookid=" + bookid + ", bookname=" + bookname + ", author1=" + author1 + ", author2="
				+ author2 + ", publisher=" + publisher + ", yearofpublication=" + yearofpublication + "]";
	}
	
}

package com.capgemini.certification.controller;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.certification.bean.AssignCertification;
import com.capgemini.certification.bean.AvailableCertifications;
import com.capgemini.certification.bean.CertificationRequest;
import com.capgemini.certification.bean.UserDetails;
import com.capgemini.certification.service.ICMSService;

/*
 * author: Crunchify.com
 * 
 */

@Controller
public class Certification {

    @Autowired
    ICMSService ICMSService;

    String empId = null;
    String username = null;

    List<AvailableCertifications> availableCertifications = null;

    @RequestMapping(value = "home", method = RequestMethod.GET)
    public ModelAndView home(@ModelAttribute("user") UserDetails user) {

        return new ModelAndView("login", "user", user);
    }

    @RequestMapping(value = "loginUser", method = RequestMethod.POST)
    public ModelAndView loginUser(@ModelAttribute("user") UserDetails user, Map<String, Object> model) {

        List<UserDetails> userList = ICMSService.vaidateUser(user);
        String role = null;
        if (userList.isEmpty()) {
            model.put("InvalidUser", true);
            return new ModelAndView("login");
        }
        model.put("InvalidUser", false);

        for (UserDetails users : userList) {
            role = users.getRole();
            username = users.getUsername();
            empId = users.getEmpId();
        }
        model.put("empId", empId);
        model.put("username", username);
        if ("admin".equalsIgnoreCase(role)) {

            return new ModelAndView("AdminLanding");
        } else if ("user".equalsIgnoreCase(role)) {

            return new ModelAndView("UserLanding");
        }

        return new ModelAndView("login", "user", user);
    }

    @RequestMapping(value = "allUsers", method = RequestMethod.GET)
    public ModelAndView viewAllUsers(Map<String, Object> model) {

        model.put("username", username);
        List<UserDetails> userList = ICMSService.viewAllUsers();
        model.put("showAllUsers", true);
        model.put("issueCertificate", false);
        model.put("approveRequests", false);
        model.put("addNewUser", false);
        return new ModelAndView("AdminLanding", "userList", userList);
    }

    @RequestMapping(value = "addUser", method = RequestMethod.GET)
    public ModelAndView addNewUser(@ModelAttribute("user") UserDetails user, Map<String, Object> model) {
        model.put("username", username);
        model.put("showAllUsers", false);
        model.put("issueCertificate", false);
        model.put("approveRequests", false);
        model.put("addNewUser", true);
        return new ModelAndView("AdminLanding");
    }

    @RequestMapping(value = "insertUser", method = RequestMethod.POST)
    public ModelAndView insertUser(@ModelAttribute("user") UserDetails user, Map<String, Object> model) {
        model.put("username", username);
        model.put("showAllUsers", false);
        model.put("addNewUser", true);
        model.put("approveRequests", false);
        ICMSService.addNewUser(user);

        model.put("showAllUsers", false);
        model.put("addNewUser", true);
        user.setEmail(null);
        user.setDesignation(null);
        user.setEmpId(null);
        user.setPassword(null);
        user.setUserId(null);
        user.setUsername(null);
        user.setBu(null);
        return new ModelAndView("AdminLanding", "userAdded", true);
    }

    @RequestMapping(value = "resetAdmin", method = RequestMethod.GET)
    public ModelAndView resetAdmin(@ModelAttribute("user") UserDetails user, Map<String, Object> model) {
        model.put("username", username);
        model.put("showAllUsers", false);
        model.put("approveRequests", false);
        model.put("addNewUser", false);
        model.put("issueCertificate", false);
        return new ModelAndView("AdminLanding");
    }

    @RequestMapping(value = "resetUser", method = RequestMethod.GET)
    public ModelAndView resetUser(@ModelAttribute("user") UserDetails user, Map<String, Object> model) {
        model.put("username", username);
        model.put("viewAllCertifications", false);
        model.put("requestCert", false);
        return new ModelAndView("UserLanding");
    }

    @RequestMapping(value = "logoutAdmin", method = RequestMethod.GET)
    public ModelAndView logoutAdmin(@ModelAttribute("user") UserDetails user) {
        username = null;
        return new ModelAndView("login", "user", user);
    }

    @RequestMapping(value = "userLogout", method = RequestMethod.GET)
    public ModelAndView userLogout(@ModelAttribute("user") UserDetails user) {
        username = null;
        return new ModelAndView("login", "user", user);
    }

    @RequestMapping(value = "assignCertification", method = RequestMethod.GET)
    public ModelAndView assignCertification(@ModelAttribute("assign") AssignCertification assign, Map<String, Object> model) {
        model.put("username", username);
        model.put("showAllUsers", false);
        model.put("approveRequests", false);
        model.put("addNewUser", false);
        availableCertifications = ICMSService.getAvailableCertifications();
        model.put("availableCertification", availableCertifications);
        return new ModelAndView("AdminLanding", "issueCertificate", true);
    }

    @RequestMapping(value = "insertCertification", method = RequestMethod.POST)
    public ModelAndView insertCertification(@ModelAttribute("assign") AssignCertification assign, Map<String, Object> model) {

        model.put("availableCertification", availableCertifications);
        List<Object> employees = ICMSService.getAllEmployees();
        if (!employees.contains(assign.getAssignedTo())) {
            model.put("invalidEmployee", true);
            return new ModelAndView("AdminLanding", "issueCertificate", true);
        }
        ICMSService.assignCertification(assign);
        model.put("certificateAssigned", true);
        model.put("invalidEmployee", false);
        assign.setAssignedDate(null);
        assign.setAssignedTime(null);
        assign.setAssignedTo(null);
        assign.setId(null);
        assign.setName(null);
        return new ModelAndView("AdminLanding", "issueCertificate", true);

    }

    @RequestMapping(value = "getAllRequests", method = RequestMethod.GET)
    public ModelAndView getAllRequests(Map<String, Object> model) {
        model.put("username", username);
        model.put("showAllUsers", false);
        model.put("issueCertificate", false);
        model.put("addNewUser", false);
        model.put("approveRequests", true);
        List<CertificationRequest> requests = ICMSService.getAllRequests();
        return new ModelAndView("AdminLanding", "requests", requests);
    }

    @RequestMapping(value = "approveRequest", method = RequestMethod.GET)
    public ModelAndView approveRequest(@RequestParam("id") Integer id, @RequestParam("requestedDate") Date requestedDate,
            @RequestParam("name") String name, @RequestParam("requestedBy") String requestedBy, Map<String, Object> model) {
        model.put("username", username);
        model.put("showAllUsers", false);
        model.put("issueCertificate", false);
        model.put("addNewUser", false);
        model.put("approveRequests", true);

        AssignCertification assign = new AssignCertification();
        assign.setAssignedDate(requestedDate);
        assign.setAssignedTime("12:00");
        assign.setAssignedTo(requestedBy);
        assign.setName(name);

        model.put("approved", true);
        ICMSService.approveRequest(id);
        ICMSService.assignCertification(assign);
        List<CertificationRequest> requests = ICMSService.getAllRequests();
        return new ModelAndView("AdminLanding", "requests", requests);
    }

    @RequestMapping(value = "viewAssignedCertifications", method = RequestMethod.GET)
    public ModelAndView viewAssignedCertifications(@RequestParam("empId") String empId, Map<String, Object> model) {
        model.put("username", username);
        model.put("viewAllCertifications", true);
        model.put("requestCert", false);
        model.put("empId", empId);
        List<AssignCertification> certifications = ICMSService.getAssignedCertifications(empId);
        return new ModelAndView("UserLanding", "certifications", certifications);
    }

    @RequestMapping(value = "requestCertification", method = RequestMethod.GET)
    public ModelAndView requestCertification(@ModelAttribute("certification") CertificationRequest certification, Map<String, Object> model) {
        availableCertifications = ICMSService.getAvailableCertifications();
        model.put("username", username);
        model.put("viewAllCertifications", false);
        model.put("availableCertification", availableCertifications);
        model.put("empId", empId);
        model.put("requestCert", true);
        return new ModelAndView("UserLanding");
    }

    @RequestMapping(value = "sendRequest", method = RequestMethod.POST)
    public ModelAndView sendRequest(@ModelAttribute("certification") CertificationRequest certification, Map<String, Object> model) {
        model.put("username", username);
        model.put("viewAllCertifications", false);
        model.put("availableCertification", availableCertifications);
        model.put("empId", empId);
        model.put("requestCert", true);
        certification.setRequestedBy(empId);
        certification.setStatus("Pending");

        ICMSService.raiseCertifications(certification);
        model.put("certReqRaised", true);
        certification.setId(null);
        certification.setRequestedBy(null);
        certification.setRequestedDate(null);
        certification.setTitle(null);
        return new ModelAndView("UserLanding");
    }

}